SITE DE DÉMONSTRATION — GitHub Pages

1. Créez un dépôt public sur GitHub.
2. Envoyez index.html à la racine du dépôt.
3. Ouvrez Settings > Pages.
4. Dans Build and deployment, choisissez Deploy from a branch.
5. Choisissez la branche main et le dossier /(root), puis Save.
6. GitHub affichera l’adresse publique du site dans la section Pages.

Cette maquette est volontairement identifiée comme démonstration fictive.
Elle ne représente aucune banque réelle et ne permet aucun paiement ou virement.
Ne remplacez pas les exemples par des données bancaires réelles.
